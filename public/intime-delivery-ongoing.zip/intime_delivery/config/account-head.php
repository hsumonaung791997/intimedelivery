<?php

return [
	"type" => ["Credit", "Debit"],
];

?>