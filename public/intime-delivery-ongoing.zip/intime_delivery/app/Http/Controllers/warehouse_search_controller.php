<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class warehouse_search_controller extends Controller
{
    //
}
