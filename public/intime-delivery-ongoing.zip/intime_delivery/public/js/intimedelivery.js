$(function() {
	$('#account_head_id').on('change', function() {
		var type = $("option:selected" , $(this)).data('type');
		$('#accountType').html(type);
	})
});