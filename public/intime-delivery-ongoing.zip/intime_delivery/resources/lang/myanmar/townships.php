<?php

return [
	'welcome' => 'Bienvenue sur notre application'
];